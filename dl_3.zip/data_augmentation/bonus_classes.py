import numpy as np
from PIL import Image
import torch

class FiveCrop(object):
    """Class for getting five crops from PIL.Image data."""
    def __init__(self, size):
        """
        Args:
            size (Union[integer, tuple]): Size of the five crops, resulting in a (W, H) size.
        """
        if type(size) == int:
            size = (size, size)
        else:
            assert len(size) == 2
        self.size = size

    def __call__(self, image):
        """
        Args:
            image (PIL.Image): Image to be cropped.

        Returns:
            tuple: Contains PIL.Image for the five crops.
        """
        # For PIL Image format
        w, h = image.size
        crop_w, crop_h = self.size
        if crop_w > w or crop_h > h:
            raise ValueError("Crop size is bigger than image size.")

        image = np.asarray(image, np.uint8)

        top_left = Image.fromarray(image[:crop_h,:crop_w,:], mode='RGB')
        top_right = Image.fromarray(image[:crop_h,w-crop_w:,:], mode='RGB')
        bottom_left = Image.fromarray(image[h-crop_h:,:crop_w,:], mode='RGB')
        bottom_right = Image.fromarray(image[h-crop_h:,w-crop_w:,:], mode='RGB')

        left = int(np.ceil((w - crop_w)/2))
        top = int(np.ceil((h - crop_h)/2))
        right = int(np.ceil((w + crop_w)/2))
        bottom = int(np.ceil((h + crop_h)/2))
        center = Image.fromarray(image[top:bottom,left:right,:], mode='RGB')

        return (top_left, top_right, bottom_left, bottom_right, center)


class ToTensor(object):
    """Class for converting PIL.Image data to Tensor."""
    def __call__(self, image):
        """
        Args:
            image (PIL.Image): Image to be converted.

        Returns:
            Tensor: Tensor image of size (C, H, W).
        """
        image = np.asarray(image, np.uint8)
        image = torch.from_numpy(image)

        # Convert from HWC to CHW format
        image = image.transpose(0, 1).transpose(0, 2).contiguous()

        if isinstance(image, torch.ByteTensor):
            return image.float().div(255)
        else:
            return image


class Normalize(object):
    """Class for normalizing image values to have a mean of zero and a variance of one."""
    def __init__(self, mean, std):
        """
        Args:
            mean (list): Mean values for image channels.
            std (list): Standard deviation values for image channels.
        """
        assert len(mean) >= 1
        assert len(std) >= 1

        self.mean = mean
        self.std = std

    def __call__(self, tensor):
        """
        Args:
            tensor (Tensor): Tensor image of size (C, H, W) to be normalized.

        Returns:
            Tensor: Normalized Tensor image.
        """
        if len(self.mean) == 1:
            for i in range(tensor.shape[0]):
                tensor[i] -= self.mean[0]
        elif len(self.mean) != 1:
            assert len(self.mean) == tensor.shape[0]
            for i in range(tensor.shape[0]):
                tensor[i] -= self.mean[i]

        if len(self.std) == 1:
            for i in range(tensor.shape[0]):
                tensor[i] /= self.std[0]
        elif len(self.std) != 1:
            assert len(self.std) == tensor.shape[0]
            for i in range(tensor.shape[0]):
                tensor[i] /= self.std[i]

        return tensor
