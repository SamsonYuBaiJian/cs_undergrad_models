# HW 3: Code
# Kevin Yee Yew Wai (1002681)
# Samson Yu Bai Jian (1002819)

Task1:
Step 1: run pytorch_logreg_gdesc_studentversion.py

Task2:
Step 1 (Slower): run Task2_code.py (requires internet connection for Fashion MNIST dataset download)
Step 1 (Faster Alternative): view/run Task2_code.ipynb

Step 2: Open Task2_graph_and_answer.docx to view loss/accuracy graph and answer to question asked